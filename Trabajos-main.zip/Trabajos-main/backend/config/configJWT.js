module.exports = {
    secret: "youraccesstokensecret", // Contraseña secreta del usuario
    expiresIn: "20m" 
};